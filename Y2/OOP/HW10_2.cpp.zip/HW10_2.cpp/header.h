#ifndef NAMESPACE1_H
#define NAMESPACE1_H
#include <iostream>

namespace MyNamespace {
    void function1(){
        std::cout << "Function1" << "\n";
    };
    void function2();
    void function3();
}

#endif